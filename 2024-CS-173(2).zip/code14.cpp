#include<iostream>
using namespace std;
main()
{  
 system("Color 97");
  cout<<"             .::---::..        "<<endl;
  cout<<"          .-------------.      "<<endl;
  cout<<"        .-----------------.    "<<endl;
  cout<<"        ----------------:.     "<<endl;
  cout<<"      :------------::.         "<<endl;
  cout<<"      ------------:.           "<<endl;
  cout<<"      :--------------:..       "<<endl;
  cout<<"       :----------------:.     "<<endl;
  cout<<"        .---------------:      "<<endl;
  cout<<"          .:---------:.        "<<endl;       
}   