#include<iostream>
using namespace std;
main()
{
 system("Color 70");
 cout<<"    ###     "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  #######   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"            "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  #####     "<<endl;
 cout<<"  #####     "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"            "<<endl;
 cout<<"  ########  "<<endl;
 cout<<"       ##   "<<endl;
 cout<<"      ##    "<<endl;
 cout<<"     ##     "<<endl;
 cout<<"    ##      "<<endl;
 cout<<"   ######## "<<endl;
 cout<<"            "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  #####     "<<endl;
 cout<<"  #####     "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"            "<<endl;
 cout<<"    ###     "<<endl;
 cout<<"  ##   ##   "<<endl;
 cout<<"  ##        "<<endl;
 cout<<"   ####     "<<endl;
 cout<<"      ###   "<<endl;
 cout<<"        ##  "<<endl;
 cout<<"  ##    ##  "<<endl;
 cout<<"   #####    "<<endl;

}